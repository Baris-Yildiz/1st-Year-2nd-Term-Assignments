
public class Board {
    private String[][] board;   // the board where the game takes place
    private int rowLength;      // row length of board
    private int columnLength;   // column length of board
    private Player player;      // the player
    private boolean gameOver;   // boolean that indicates whether the game is over.

    public Board(String[][] board){
        setBoard(board);
        setRowLength(getBoard().length);
        setColumnLength(getBoard()[0].length);
    }

    // returns board field
    public String[][] getBoard() {
        return board;
    }

    // updates board field
    public void setBoard(String[][] board) {
        this.board = board;
    }

    // returns rowLength field
    public int getRowLength() {
        return rowLength;
    }

    // updates rowLength field
    public void setRowLength(int rowLength) {
        this.rowLength = rowLength;
    }

    // returns columnLength
    public int getColumnLength() {
        return columnLength;
    }

    // updates columnLength
    public void setColumnLength(int columnLength) {
        this.columnLength = columnLength;
    }

    // returns player
    public Player getPlayer() {
        return player;
    }

    // updates player
    public void setPlayer(Player player) {
        this.player = player;
    }

    // returns gameOver
    public boolean isGameOver() {
        return gameOver;
    }

    // updates gameOver
    public void setGameOver(boolean gameOver) {
        this.gameOver = gameOver;
    }

    /* Precondition: rowIndex2 and columnIndex2 are the row and column indexes
    of the next position of the player.
    Postcondition: returns whether the player can swap positions with the object
    at its next position */
    public boolean canSwapPositions(int rowIndex2, int columnIndex2){
        String swapped = getBoard()[rowIndex2][columnIndex2];
        return !(swapped.equals("H") || swapped.equals("W"));
    }

    /* Precondition: rowIndex1, columnIndex1 are the initial positions of the player,
    rowIndex2, columnIndex2 are the final/next positions of the player.
    Postcondition: swaps the positions of the player and the object at the player's
    next position */
    public void swapPositions(int rowIndex1, int columnIndex1, int rowIndex2, int columnIndex2){
        String swapped = getBoard()[rowIndex2][columnIndex2];
        getBoard()[rowIndex2][columnIndex2] = getBoard()[rowIndex1][columnIndex1];

        switch (swapped){
            case "R":
                swapped = "X";
                getPlayer().setPoints(getPlayer().getPoints() + 10);
                break;
            case "Y":
                swapped = "X";
                getPlayer().setPoints(getPlayer().getPoints() + 5);
                break;
            case "B":
                swapped = "X";
                getPlayer().setPoints(getPlayer().getPoints() - 5);
                break;
        }

        getBoard()[rowIndex1][columnIndex1] = swapped;

    }

    /* Precondition: rowIndex2, columnIndex2 are the final/next positions of the player.
    oppositeDirection is the direction the player should move towards if there was a wall at
    rowIndex2, columnIndex2.
    Postcondition: performs different movements depending on the obstacle at rowIndex2, columnIndex2 */
    public void doNonSwapMovement(int rowIndex2, int columnIndex2, String oppositeDirection){
        String obstacle = getBoard()[rowIndex2][columnIndex2];
        switch (obstacle){
            case "W":
                getPlayer().movePlayer(oppositeDirection);
                break;
            case "H":
                fallDown();
                break;
        }
    }

    // makes the player fall in the hole and ends the game.
    private void fallDown(){
        setGameOver(true);
        getBoard()[getPlayer().getRowIndex()][getPlayer().getColumnIndex()] = " ";
    }

    // returns "Game Over" if the game ended with the player falling in the hole.
    public String gameOverMessage(){
        if(isGameOver()){
            return "Game Over!\n";
        }
        return "";
    }

    @Override
    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        for (String[] row : getBoard()) {
            stringBuilder.append(String.join(" ", row)).append("\n");
        }
        return stringBuilder.toString();
    }
}
