
public class Main {

    public static void main(String[] args) {
        // store board and move files.
        String boardFile = args[0];
        String moveFile = args[1];

        // store board and moves in arrays
        String[] boardRows = FileIO.readFile(boardFile);
        String[] moves = FileIO.readFile(moveFile)[0].split(" ");

        // make the board a 2D array.
        String[][] board = new String[boardRows.length][];
        int playerRow = 0;
        int playerColumn = 0;
        for (int i = 0; i < boardRows.length; i++) {
            board[i] = boardRows[i].split(" ");
            for(int j = 0; j < board[i].length; j++){
                if(board[i][j].equals("*")){        // locate the player
                    playerRow = i;
                    playerColumn = j;
                }
            }
        }

        // initialize Board and Player objects.
        Board gameBoard = new Board(board);
        Player player = new Player(playerRow, playerColumn, gameBoard);
        gameBoard.setPlayer(player);

        // initialize a StringBuilder to store output.
        StringBuilder output = new StringBuilder();
        output.append("Game board:\n").append(gameBoard).append("\n");
        output.append("Your movement is:\n");

        // play the game
        for (String move : moves) {
            output.append(move).append(" ");
            player.movePlayer(move);
            if(gameBoard.isGameOver()){
                break;
            }
        }
        output.deleteCharAt(output.length() - 1);

        // store ending message in the output
        output.append("\n\n").append("Your output is:\n").append(gameBoard).append("\n");
        output.append(gameBoard.gameOverMessage()).append("Score: ").append(player.getPoints());

        // write the output to output.txt
        FileIO.writeFile("output.txt", output.toString());
    }
}