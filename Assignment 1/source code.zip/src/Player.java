
public class Player {
    private int rowIndex;       //current row of player
    private int columnIndex;    //current column of player
    private Board gameBoard;    //the board where the player is moving
    private int points;         //total points of player

    public Player(int rowIndex, int columnIndex, Board gameBoard){
        setGameBoard(gameBoard);
        setRowIndex(rowIndex);
        setColumnIndex(columnIndex);
        setPoints(0);
    }

    // clamps and returns rowIndex so that it is not out of bounds
    private int clampRowIndex(int rowIndex){
        if(rowIndex < 0){
            return getGameBoard().getRowLength()-1;
        }
        else if(rowIndex > getGameBoard().getRowLength()-1){
            return 0;
        }
        return rowIndex;
    }

    // returns rowIndex field
    public int getRowIndex() {
        return rowIndex;
    }

    // updates rowIndex field
    public void setRowIndex(int rowIndex) {
        this.rowIndex = clampRowIndex(rowIndex);
    }

    // clamps and returns columnIndex so that it is not out of bounds
    private int clampColumnIndex(int columnIndex){
        if(columnIndex < 0){
            return getGameBoard().getColumnLength()-1;
        }
        else if(columnIndex > getGameBoard().getColumnLength()-1){
            return 0;
        }
        return columnIndex;
    }

    // returns columnIndex field
    public int getColumnIndex() {
        return columnIndex;
    }

    // updates columnIndex field
    public void setColumnIndex(int columnIndex) {
        this.columnIndex = clampColumnIndex(columnIndex);
    }

    // returns gameBoard field
    public Board getGameBoard() {
        return gameBoard;
    }

    // updates gameBoard field
    public void setGameBoard(Board gameBoard) {
        this.gameBoard = gameBoard;
    }

    // returns points field
    public int getPoints() {
        return points;
    }

    // updates points field
    public void setPoints(int points) {
        this.points = points;
    }

    // moves the player 1 unit left
    private void moveLeft(){
        int newColumn = clampColumnIndex(getColumnIndex() - 1);
        if(getGameBoard().canSwapPositions(getRowIndex(), newColumn)){
            getGameBoard().swapPositions(getRowIndex(), getColumnIndex(), getRowIndex(), newColumn);
            setColumnIndex(newColumn);
        }
        else{
            getGameBoard().doNonSwapMovement(getRowIndex(), newColumn, "R");
        }
    }

    // moves the player 1 unit right
    private void moveRight(){
        int newColumn = clampColumnIndex(getColumnIndex() + 1);
        if(getGameBoard().canSwapPositions(getRowIndex(), newColumn)){
            getGameBoard().swapPositions(getRowIndex(), getColumnIndex(), getRowIndex(), newColumn);
            setColumnIndex(newColumn);
        }
        else{
            getGameBoard().doNonSwapMovement(getRowIndex(), newColumn, "L");
        }
    }

    // moves the player 1 unit up
    private void moveUp(){
        int newRow = clampRowIndex(getRowIndex() - 1);
        if(getGameBoard().canSwapPositions(newRow, getColumnIndex())){
            getGameBoard().swapPositions(getRowIndex(), getColumnIndex(), newRow, getColumnIndex());
            setRowIndex(newRow);
        }
        else{
            getGameBoard().doNonSwapMovement(newRow, getColumnIndex(), "D");
        }
    }

    // moves the player 1 unit down
    private void moveDown(){
        int newRow = clampRowIndex(getRowIndex() + 1);
        if(getGameBoard().canSwapPositions(newRow, getColumnIndex())){
            getGameBoard().swapPositions(getRowIndex(), getColumnIndex(), newRow, getColumnIndex());
            setRowIndex(newRow);
        }
        else{
            getGameBoard().doNonSwapMovement(newRow, getColumnIndex(), "U");
        }
    }

    /* Precondition: argument "move" must be either L, R, U or D.
    Postcondition: calls the appropriate method to move the player
    into the direction "move" implies. */
    public void movePlayer(String move){
        switch (move){
            case "L":
                moveLeft();
                break;
            case "R":
                moveRight();
                break;
            case "U":
                moveUp();
                break;
            case "D":
                moveDown();
                break;
        }
    }
}
