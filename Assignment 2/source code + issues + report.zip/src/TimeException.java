/**
 * TimeException gets thrown in time related inconveniences.
 */
class TimeException extends RuntimeException {
    public TimeException(String message) {
        super(message);
    }
}
