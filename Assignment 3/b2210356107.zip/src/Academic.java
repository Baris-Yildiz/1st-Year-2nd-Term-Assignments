public class Academic extends Member {

    /**
     * Constructor for Academic members.
     * Used to set book and extension week limits.
     */
    public Academic() {
        setBookLimit(4);
        setExtensionWeeks(2);
    }

    /**
     * Used in the listAllEntities method of the Library class in order to get
     * the name of the class in the appropriate form.
     * @return the string "academic"
     */
    @Override
    public String getClassName() {
        return "academic";
    }

    /**
     * toString method for Academic class returns the class name with the
     * id of the object in brackets.
     * @return the string "Academic [id: <i>id_of_object</i> ]"
     */
    @Override
    public String toString() {
        return "Academic [id: " + getMemberID() + "]";
    }
}
