import java.time.LocalDate;

public abstract class Book extends LibraryEntity {

    //fields for keeping track of the total borrowed and read books at a time.
    public static int totalBorrowedBooks;
    public static int totalBooksBeingReadInLibrary;

    //fields for assigning IDs to Book objects.
    private final int bookID;
    private static int latestBookID = 0;

    //fields representing the properties of books that are borrowed.
    private boolean isBorrowed;
    private LocalDate borrowDate;
    private Member borrowedBy;
    private boolean isExtended;
    private LocalDate deadline;

    //fields representing the properties of books that are read.
    private boolean isBeingRead;
    private Member readBy;
    private LocalDate readDate;

    /**
     * Constructor for Book objects. Used for assigning IDs to Member objects.
     */
    public Book() {
        if (latestBookID == 999999) {
            throw new MemberException("The ID limit for books has been reached!");
        }
        latestBookID++;
        bookID = latestBookID;
    }

    public int getBookID() {
        return bookID;
    }

    public boolean isBorrowed() {
        return isBorrowed;
    }

    public void setBorrowed(boolean borrowed) {
        if (borrowed) {
            totalBorrowedBooks++;
        } else {
            totalBorrowedBooks--;
        }
        isBorrowed = borrowed;
    }

    public LocalDate getBorrowDate() {
        return borrowDate;
    }

    public void setBorrowDate(LocalDate borrowDate) {
        this.borrowDate = borrowDate;
        setDeadline(borrowDate.plusWeeks(borrowedBy.getExtensionWeeks()));
    }

    public Member getBorrowedBy() {
        return borrowedBy;
    }

    public void setBorrowedBy(Member borrowedBy) {
        this.borrowedBy = borrowedBy;
    }

    public boolean isExtended() {
        return isExtended;
    }

    public void setExtended(boolean extended) {
        isExtended = extended;
    }

    public LocalDate getDeadline() {
        return deadline;
    }

    public void setDeadline(LocalDate deadline) {
        this.deadline = deadline;
    }

    public boolean isBeingRead() {
        return isBeingRead;
    }

    public void setBeingRead(boolean beingRead) {
        if (beingRead) {
            totalBooksBeingReadInLibrary++;
        } else {
            totalBooksBeingReadInLibrary--;
        }

        isBeingRead = beingRead;
    }

    public Member getReadBy() {
        return readBy;
    }

    public void setReadBy(Member readBy) {
        this.readBy = readBy;
    }

    public LocalDate getReadDate() {
        return readDate;
    }

    public void setReadDate(LocalDate readDate) {
        this.readDate = readDate;
    }

}
