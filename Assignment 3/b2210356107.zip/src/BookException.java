/**
 * BookException covers exceptions regarding books and book operations such as borrowing,
 * extending, reading and returning.
 */
public class BookException extends RuntimeException {
    public BookException(String message) {
        super(message);
    }
}
