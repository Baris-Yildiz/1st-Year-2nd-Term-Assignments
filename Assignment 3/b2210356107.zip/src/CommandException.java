/**
 * CommandException covers command related exceptions like invalid argument exceptions and
 * invalid command exceptions.
 */
public class CommandException extends RuntimeException {
    public CommandException(String message) {
        super(message);
    }
}
