import java.time.Duration;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Library {
    // collections for storing books and members.
    static List<Book> books = new ArrayList<>();
    static List<Book> printedBooks = new ArrayList<>();
    static List<Book> handWrittenBooks = new ArrayList<>();

    static List<Member> members = new ArrayList<>();
    static List<Member> students = new ArrayList<>();
    static List<Member> academics = new ArrayList<>();

    /**
     * Adds a book to the system.
     * @param bookType "P" for "Printed Book" or "H" for "HandWritten Book".
     * @return a message about the creation of the book.
     * @throws BookException if bookType is not "P" nor "H".
     */
    public static String addBook(String bookType) throws BookException{

        Book book;

        if (bookType.equals("P")) {
            book = new PrintedBook();
            books.add(book);
            printedBooks.add(book);
        } else if (bookType.equals("H")) {
            book = new HandWrittenBook();
            books.add(book);
            handWrittenBooks.add(book);
        } else {
            throw new BookException("Book cannot be added: Invalid book type!");
        }

        return "Created new book: " + book;
    }

    /**
     * Adds a member to the system.
     * @param type "A" for "Academician" or "S" for "Student".
     * @return a message about the creation of the member.
     * @throws MemberException if type is not "A" nor "S".
     */
    public static String addMember(String type) throws MemberException {

        Member member;

        if (type.equals("A")) {
            member = new Academic();
            members.add(member);
            academics.add(member);
        } else if (type.equals("S")) {
            member = new Student();
            members.add(member);
            students.add(member);
        } else {
            throw new MemberException("Member cannot be added: Invalid member type!");
        }

        return "Created new member: " + member;
    }

    /**
     * Gets the member that an id represents.
     * @param memberId the id of the member that wants to be fetched.
     * @return the book memberId represents.
     * @throws MemberException if memberId doesn't represent a member.
     */
    private static Member getMember(int memberId) throws MemberException {

        if (memberId > members.size() || memberId <= 0) {
            throw new MemberException("Error: Member doesn't exist!");
        }

        return members.get(memberId - 1);
    }

    /**
     * Gets the book that an id represents.
     * @param bookId the id of the book that wants to be fetched.
     * @return the book bookId represents.
     * @throws MemberException if bookId doesn't represent a member.
     */
    private static Book getBook(int bookId) throws BookException {

        if (bookId > books.size() || bookId <= 0) {
            throw new BookException("Error: Book doesn't exist!");
        }

        return books.get(bookId - 1);
    }

    /**
     * @return whether a book is busy (is being read or borrowed by a member at that time).
     */
    private static boolean isBookBusy(Book book) {
        return book.isBorrowed() || book.isBeingRead();
    }

    /**
     * Makes a member borrow a book.
     * @param bookId the id of the book being borrowed.
     * @param memberId the id of the member borrowing.
     * @param currentDate the date when the borrowing occurs.
     * @return a string about the result.
     * @throws BookException if the book cannot be borrowed. i.e. it doesn't exist, it is a handwritten book, it is already borrowed, or
     * member has reached the book limit.
     */
    public static String borrowBook(int bookId, int memberId, LocalDate currentDate) throws BookException {

        Member member = getMember(memberId);
        Book book = getBook(bookId);

        if (book instanceof HandWrittenBook || isBookBusy(book)) {
            throw new BookException("You cannot borrow this book!");
        }

        if (member.getBookLimit() == member.getBorrowedBooks().size()) {
            throw new BookException("You have exceeded the borrowing limit!");
        }

        book.setBorrowed(true);
        book.setBorrowedBy(member);
        member.getBorrowedBooks().add(book);
        book.setBorrowDate(currentDate);

        return "The book [" + bookId + "] was borrowed by member [" + memberId + "] at " + currentDate;
    }

    /**
     * Makes a member return a book. A member can return a book that he/she has borrowed or a book that he/she was reading in the library.
     * @param bookId id of the returned book
     * @param memberId id of the returner member
     * @param currentDate date when the returning takes place.
     * @return a string about the result.
     * @throws BookException if the book cannot be returned. i.e. it isn't among the books that the member has borrowed / has read, the date is before
     * the borrowed/read date etc.
     */
    public static String returnBook(int bookId, int memberId, LocalDate currentDate) throws BookException {

        Member member = getMember(memberId);
        Book book = getBook(bookId);
        long fee = 0;

        if (book.isBorrowed()) {
            if(!member.getBorrowedBooks().contains(book) || currentDate.isBefore(book.getBorrowDate())) {
                throw new BookException("Book cannot be returned!");
            }

            if (book.getDeadline().isBefore(currentDate)) {
                Duration duration = Duration.between(book.getDeadline().atStartOfDay(), currentDate.atStartOfDay());
                fee = duration.toDays();
            }

            book.setBorrowed(false);
            book.setBorrowedBy(member);
            member.getBorrowedBooks().remove(book);

            if(book.isExtended()) {
                book.setExtended(false);
            }

        } else if (book.isBeingRead()) {

            if (!book.getReadBy().equals(member) || currentDate.isBefore(book.getReadDate())) {
                throw new BookException("Book cannot be returned!");
            }

            book.setBeingRead(false);
        } else {
            throw new BookException("Book cannot be returned!");
        }

        return "The book [" + bookId + "] was returned by member [" + memberId + "] at " + currentDate + " Fee: " + fee;
    }

    /**
     * Makes a member extend the deadline of the book he/she borrowed.
     * @param bookId id of the book.
     * @param memberId id of the member.
     * @param currentDate date when the extension takes place.
     * @return a string about the result.
     * @throws BookException if the book cannot be extended. i.e. if the book has already been extended, book isn't among the books borrowed by the
     * member etc.
     */
    public static String extendBook(int bookId, int memberId, LocalDate currentDate) throws BookException {

        Member member = getMember(memberId);
        Book book = getBook(bookId);

        if (!member.getBorrowedBooks().contains(book) || book.isExtended() || currentDate.isAfter(book.getDeadline()) || currentDate.isBefore(book.getBorrowDate())) {
            throw new BookException("You cannot extend the deadline!");
        }

        LocalDate newDeadline = book.getDeadline().plusWeeks(member.getExtensionWeeks());
        book.setDeadline(newDeadline);
        book.setExtended(true);

        return "The deadline of book [" + bookId +"] was extended by member [" + memberId + "] at " + currentDate + "\n" +
                "New deadline of book [" + bookId + "] is " + book.getDeadline();

    }

    /**
     * Makes a member read a book in the library.
     * @param bookId id of the book.
     * @param memberId id of the member.
     * @param currentDate date when the reading begins.
     * @return a string about the result.
     * @throws BookException if the book is busy.
     * @throws MemberException if the book is a handwritten book and the member is a student.
     */
    public static String readInLibrary(int bookId, int memberId, LocalDate currentDate) throws BookException, MemberException {

        Member member = getMember(memberId);
        Book book = getBook(bookId);

        if (isBookBusy(book)) {
            throw new BookException("You can not read this book!");
        }

        if (book instanceof HandWrittenBook && member instanceof Student) {
            throw new MemberException("Students can not read handwritten books!");
        }

        book.setBeingRead(true);
        book.setReadBy(member);
        book.setReadDate(currentDate);

        return "The book [" + bookId +"] was read in library by member [" + memberId + "] at " + currentDate;
    }

    /**
     * Lists a certain LibraryEntity collection's contents.
     * @param arrayList an arrayList. Used with the fields of the Library class: printedBooks, handWrittenBooks,
     * academics and students.
     * @return a string the joins all elements of the arrayList
     * @param <T> a type that has the upper limit LibraryEntity.
     */
    private static <T extends LibraryEntity> String listAllEntities(List<T> arrayList) {
        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("Number of ").append(arrayList.get(0).getClassName()).append("s: ").append(arrayList.size()).append("\n");
        for (Object object : arrayList) {
            stringBuilder.append(object).append("\n");
        }

        return stringBuilder.toString();
    }

    /**
     * Gets the history of the library.
     * @return a string that lists all books, members, books that were borrowed and books that are read in the library.
     */
    public static String getTheHistory() {
        StringBuilder stringBuilder = new StringBuilder();

        stringBuilder.append("History of library:\n\n");

        stringBuilder.append(listAllEntities(students)).append("\n");
        stringBuilder.append(listAllEntities(academics)).append("\n");
        stringBuilder.append(listAllEntities(printedBooks)).append("\n");
        stringBuilder.append(listAllEntities(handWrittenBooks)).append("\n");


        stringBuilder.append("Number of borrowed books: ").append(Book.totalBorrowedBooks).append("\n");

        for (Book book : books) {
            if (book.isBorrowed()) {
                stringBuilder.append("The book ").append("[").append(book.getBookID()).append("]")
                        .append(" was borrowed by member [").append(book.getBorrowedBy().getMemberID())
                        .append("] at ").append(book.getBorrowDate()).append("\n");
            }
        }

        stringBuilder.append("\nNumber of books read in library: ").append(Book.totalBooksBeingReadInLibrary).append("\n");

        for (Book book : books) {
            if (book.isBeingRead()) {
                stringBuilder.append("The book ").append("[").append(book.getBookID()).append("]")
                        .append(" was read in library by member [").append(book.getReadBy().getMemberID())
                        .append("] at ").append(book.getReadDate()).append("\n");
            }
        }

        return stringBuilder.toString().trim();
    }
}
