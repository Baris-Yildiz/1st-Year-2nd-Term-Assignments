/**
 * LibraryEntity represents Members and Books.
 * It contains the method getClassName that is implemented in Member and Book classes.
 */
public abstract class LibraryEntity {
    public abstract String getClassName();
}
