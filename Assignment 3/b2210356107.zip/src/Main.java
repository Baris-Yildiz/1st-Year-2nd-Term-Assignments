import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException, NoSuchMethodException, IllegalAccessException {

        String inputFile = args[0];

        Scanner input = null;

        //checking if the file is unreachable.
        try {
            input = new Scanner(new File(inputFile));
        } catch (IOException e) {
            System.out.println("Failed to reach file.");
            System.exit(0);
        }

        StringBuilder output = new StringBuilder();

        //mapping commands to methods (of the Library class) that take 1 argument.
        Map<String, Method> unaryMethodMap = new HashMap<>();
        unaryMethodMap.put("addBook", Library.class.getMethod("addBook", String.class));
        unaryMethodMap.put("addMember", Library.class.getMethod("addMember", String.class));

        //mapping commands to methods (of the Library class) that take 3 arguments.
        Map<String, Method> ternaryMethodMap = new HashMap<>();
        ternaryMethodMap.put("borrowBook", Library.class.getMethod("borrowBook", int.class, int.class, LocalDate.class));
        ternaryMethodMap.put("returnBook", Library.class.getMethod("returnBook", int.class, int.class, LocalDate.class));
        ternaryMethodMap.put("extendBook", Library.class.getMethod("extendBook", int.class, int.class, LocalDate.class));
        ternaryMethodMap.put("readInLibrary", Library.class.getMethod("readInLibrary", int.class, int.class, LocalDate.class));

        String currentLine, command, lineOutput;
        String[] arguments;

        //iterating over the input lines.
        while (input.hasNextLine()) {

            currentLine = input.nextLine();
            arguments = currentLine.split("\t");
            command = arguments[0];

            if (!command.isEmpty()) {
                try {
                    //invoking the Library class method related with the command.
                    if (arguments.length == 2 && unaryMethodMap.containsKey(command)) {
                        lineOutput = (String) unaryMethodMap.get(command).invoke(null, arguments[1]);
                    } else if (arguments.length == 4 && ternaryMethodMap.containsKey(command)) {
                        lineOutput = (String) ternaryMethodMap.get(command).invoke(null, Integer.parseInt(arguments[1]), Integer.parseInt(arguments[2]), LocalDate.parse(arguments[3]));
                    } else if (command.equals("getTheHistory")) {
                        lineOutput = Library.getTheHistory();
                    } else if (!unaryMethodMap.containsKey(command) && !ternaryMethodMap.containsKey(command)){
                        throw new CommandException("Invalid command.");
                    } else {
                        throw new CommandException("Argument number of this command is invalid!");
                    }

                    output.append(lineOutput).append("\n");

                } catch (NumberFormatException | DateTimeParseException e) {    //invalid argument errors.
                    output.append("An invalid argument was found!\n");
                } catch (CommandException e) {      //command errors and invalid number of arguments.
                    output.append(e.getMessage()).append("\n");
                } catch (InvocationTargetException e) {     // BookExceptions and MemberExceptions. Exceptions about the library system.
                    output.append(e.getCause().getMessage()).append("\n");
                }
            }

        }

        String outputFileName = args[1];

        FileWriter outputFile = new FileWriter(outputFileName);

        //writing the output to the output file.
        outputFile.write(output.toString().trim());
        outputFile.close();

    }
}