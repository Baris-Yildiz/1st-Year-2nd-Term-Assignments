
import java.util.ArrayList;
import java.util.List;

public abstract class Member extends LibraryEntity {

    // fields used for determining the id of Member objects.
    private final int memberID;
    private static int latestBookID;

    // fields used for keeping track of borrowed books.
    private final List<Book> borrowedBooks = new ArrayList<>();
    private int bookLimit;
    private long extensionWeeks;

    /**
     * Constructor for Member objects. Used for assigning IDs to Member objects.
     */
    public Member() {
        if (latestBookID == 999999) {
            throw new MemberException("The ID limit for members has been reached!");
        }
        latestBookID++;
        memberID = latestBookID;
    }

    public int getMemberID() {
        return memberID;
    }

    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }

    public int getBookLimit() {
        return bookLimit;
    }

    public void setBookLimit(int bookLimit) {
        this.bookLimit = bookLimit;
    }

    public long getExtensionWeeks() {
        return extensionWeeks;
    }

    public void setExtensionWeeks(long extensionWeeks) {
        this.extensionWeeks = extensionWeeks;
    }

}
