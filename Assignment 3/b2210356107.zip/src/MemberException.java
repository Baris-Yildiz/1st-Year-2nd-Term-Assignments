/**
 * MemberException covers member related exceptions like invalid member exceptions and non-existent
 * member exceptions.
 */
public class MemberException extends RuntimeException {
    public MemberException(String message) {
        super(message);
    }
}
