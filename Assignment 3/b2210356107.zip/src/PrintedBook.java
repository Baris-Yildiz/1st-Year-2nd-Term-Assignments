public class PrintedBook extends Book {

    /**
     * Used in the listAllEntities method of the Library class in order to get
     * the name of the class in the appropriate form.
     * @return the string "printed book"
     */
    @Override
    public String getClassName() {
        return "printed book";
    }

    /**
     * toString method for Academic class returns the class name with the
     * id of the object in brackets.
     * @return the string "PrintedBook [id: <i>id_of_object</i> ]"
     */
    @Override
    public String toString() {
        return "Printed [id: " + getBookID() + "]";
    }

}
