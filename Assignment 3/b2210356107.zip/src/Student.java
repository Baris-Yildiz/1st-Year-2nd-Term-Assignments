public class Student extends Member {
    /**
     * Constructor for Students.
     * Used to set book and extension week limits.
     */
    public Student() {
        setBookLimit(2);
        setExtensionWeeks(1);
    }

    /**
     * Used in the listAllEntities method of the Library class in order to get
     * the name of the class in the appropriate form.
     * @return the string "student"
     */
    @Override
    public String getClassName() {
        return "student";
    }

    /**
     * toString method for Student class returns the class name with the
     * id of the object in brackets.
     * @return the string "Student [id: <i>id_of_object</i> ]"
     */
    @Override
    public String toString() {
        return "Student [id: " + getMemberID() + "]";
    }
}
