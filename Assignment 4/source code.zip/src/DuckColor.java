/**
 * Enum that represents the Duck colors.
 */
public enum DuckColor {
    BLACK,
    BLUE,
    RED
}
